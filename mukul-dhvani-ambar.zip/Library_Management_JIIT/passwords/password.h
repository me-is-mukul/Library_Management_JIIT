#ifndef PASSWORD_H
#define PASSWORD_H

int passing();

#endif
