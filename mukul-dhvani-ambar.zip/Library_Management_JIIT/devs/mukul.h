#ifndef MUKUL_H
#define MUKUL_H

void main_loop(int men, WINDOW *win);

#endif
